---
title: "Broadening the scope: Multiple functional connectivity networks underlying threat and safety signaling"
authors:
- Cody A Cushing
- admin 
- Zachary Anderson
- Katherine S. Young
- Susan Y. Bookheimer 
- Richard E. Zinbarg
- Robin Nusslock
- Michelle G. Craske
author_notes:
- 
- 
-
-
-
-
-
- "Corresponding author"
date: "2023-08-21T00:00:00Z"
doi: "https://doi.org/10.1101/2023.08.16.553609"

# Schedule page publish date (NOT publication's date).
publishDate: "2023-08-21T00:00:00Z"

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["2"]

# Publication name and optional abbreviated publication name.
publication: "*bioRxiv*"
publication_short: ""

abstract: "

Introduction: Threat learning and extinction processes are thought to be foundational to anxiety and fear-related disorders. However, the study of these processes in the human brain has largely focused on a priori regions of interest, owing partly to the ease of translating between these regions in human and non-human animals. Moving beyond analyzing focal regions of interest to whole-brain dynamics during threat learning is essential for understanding the neuropathology of fear-related disorders in humans. 

Methods: 223 participants completed a 2-day Pavlovian threat conditioning paradigm while undergoing fMRI. Participants completed threat acquisition and extinction. Extinction recall was assessed 48 hours later. Using a data-driven group independent component analysis (ICA), we examined large-scale functional connectivity networks during each phase of threat conditioning. Connectivity networks were tested to see how they responded to conditional stimuli during early and late phases of threat acquisition and extinction and during early trials of extinction recall. 

Results: A network overlapping with the default mode network involving hippocampus, vmPFC, and posterior cingulate was implicated in threat acquisition and extinction. Another network overlapping with the salience network involving dACC, mPFC, and inferior frontal gyrus was implicated in threat acquisition and extinction recall. Other networks overlapping with parts of the salience, somatomotor, visual, and fronto-parietal networks were involved in the acquisition or extinction of learned threat responses. 

Conclusions: These findings help confirm previous investigations of specific brain regions in a model-free fashion and introduce new findings of spatially independent networks during threat and safety learning. Rather than being a single process in a core network of regions, threat learning involves multiple brain networks operating in parallel coordinating different functions at different timescales. Understanding the nature and interplay of these dynamics will be critical for comprehensive understanding of the multiple processes that may be at play in the neuropathology of anxiety and fear-related disorders."

# Summary. An optional shortened abstract.
summary: TBD.

tags:
- Source Themes
featured: false

# links:
# - name: ""
#   url: ""
url_pdf: 'https://www.biorxiv.org/content/10.1101/2023.08.16.553609v1'


# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
# image:
#   caption: 'Image credit: [**Advances in Psychological Science**](https://journal.psych.ac.cn/xlkxjz/CN/10.3724/SP.J.1042.2023.00905)'
#   focal_point: ""
#   preview_only: false

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
projects: []

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
# slides: example
---

{{% callout note %}}
Click the *Cite* button above to demo the feature to enable visitors to import publication metadata into their reference management software.
{{% /callout %}}

{{% callout note %}}
Create your slides in Markdown - click the *Slides* button to check out the example.
{{% /callout %}}

Supplementary notes can be added here, including [code, math, and images](https://wowchemy.com/docs/writing-markdown-latex/).
